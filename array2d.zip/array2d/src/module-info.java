module array2d {
	exports array2d;
}