package array2d;
import java.util.Iterator;
public class Student {

	int regno;
	String name;
	
	Student(int r, String n){
		regno = r;
		name = n;
		
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
