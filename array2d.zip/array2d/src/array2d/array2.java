package array2d;
import java.util.Scanner;
public class array2<T> {
	
		T data[];
		int size ;
		
		
		array2()
		{
			this(1);
		}
		
		public array2(int inicap) {
			if (inicap>0) {
				data=(T[]) new Object[inicap];
			}
			else if(inicap==0) {
				data=(T[]) new Object[0];
			}
			else {
				throw new IllegalArgumentException("initial capaity cannot be negitive");
			}
		}
		
		
		public void ensurecapacity(){
			if(data.length<= size)
			{
				int oldcap;
				int newcap;
				
				oldcap=data.length;
				newcap=oldcap +1;
				T temp[]=(T[]) new Object[newcap];
				
				for(int i=0; i<data.length;i++) {
					temp[i]=data[i];
				}
				data=temp;
			}
		}
		
		
		
		public void add(T value) {
			
				ensurecapacity();
				data[size]=value;
				size++;
		
		}
		
		public void add(int index, T value) {
			if(index>size-1 || index<0) {
				throw new ArrayIndexOutOfBoundsException();
				}
			ensurecapacity();
			for(int i=size-1; i>index; i-- ) {
				data[i+1]=data[i];
			}
			data[size]=value;
			size++;
			
		}
		
		public T remove(int index)
		{
			if(index>size-1 || index<0)
			{
				throw new ArrayIndexOutOfBoundsException();
			}
			T temp=data[index];
			for (int i = index; i < data.length-1; i++) {
				data[i]=data[i+1];
			}
			size--;
			data[size]=null;
			return temp;
		}
		

		public T get(int index)
		{
			if(index>size-1 || index<0)
			{
				throw new ArrayIndexOutOfBoundsException();
			}
			return data[index];
		}
		
		public int indexof(T value)
		{
			for (int i = 0; i < data.length; i++) {
				if(data[i]==value)
				{
					return i;
				}
			}
			return -1;
		}
		
		public boolean contains(T value)
		{
			if(indexof(value)!=-1)
			{
				return true;
			}
			return false;
		}
		
		public boolean isEmpty()
		{
			if(data[0]==null)
			{
				return true;
			}
			else
				return false;
		}
		
		
		
		public void display() {
			System.out.print("[");
			for (int i=0; i<data.length; i++) {
				System.out.print("\t" +data[i]+ "\t");
			}
			System.out.println("]");
		}
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub
		array2<Integer> a=new array2();
		
			a.add(1);
			a.add(2);
			a.add(3);
			a.add(4);
			a.display();
			a.add(2,7);
			a.display();
			a.remove(2);
			a.display();
			}

	}



		



	